"""AI-assisted local cross-environment rerun; never credit the user with manual work."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import sys
import time

import imageio_ffmpeg

M3 = Path(__file__).resolve().parents[1]
ROOT = M3 / 'B_verify_20261018'
OUT = M3 / 'B_local_20261018'
assert not OUT.exists(), 'Use a new run directory; do not overwrite a previous run.'
OUT.mkdir()
(OUT/'logs').mkdir()
(OUT/'bin').mkdir()
ffmpeg_source = Path(imageio_ffmpeg.get_ffmpeg_exe())
ffmpeg = OUT/'bin/ffmpeg.exe'
shutil.copy2(ffmpeg_source,ffmpeg)
version=subprocess.run([str(ffmpeg),'-version'],capture_output=True,text=True,check=True).stdout
env=os.environ.copy()
env['PATH']=str(ffmpeg.parent)+os.pathsep+env.get('PATH','')
env['PYTHONPATH']=str(ROOT/'src')
env['MPLCONFIGDIR']=str(OUT/'mplcache')
env['MPLBACKEND']='Agg'
env['PYTHONUTF8']='1'
env['M3_PRIVATE_DIR']=str(ROOT/'data/private/dark_mimic')
env.pop('M3_REGENERATE_NEUTRAL',None)

stamp=lambda: datetime.now(timezone(timedelta(hours=8))).isoformat(timespec='seconds')
metadata={
    'started_at':stamp(),'operator':'Codex-assisted local execution; not a record of manual execution by He Hongjie',
    'python':sys.version,'platform':platform.platform(),'python_executable':sys.executable,
    'packages':{p:importlib.metadata.version(p) for p in ['numpy','pandas','matplotlib','opencv-contrib-python','pytest']},
    'ffmpeg_version':version.splitlines()[0],
    'ffmpeg_source':str(ffmpeg_source),'ffmpeg_sha256':hashlib.sha256(ffmpeg.read_bytes()).hexdigest(),
    'environment_match':'Uses existing Windows workspace environment; not the pinned macOS handoff environment',
    'reference_results_preserved':True,'steps':[],
}
(OUT/'environment.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')

def run(name,args,extra=None):
    command=[sys.executable,*args]
    current=env.copy()
    current.update(extra or {})
    step={'name':name,'command':command,'cwd':str(ROOT),'started_at':stamp(),
          'environment_overrides':extra or {},'log':str(OUT/'logs'/f'{name}.log')}
    print('START',name,flush=True)
    start=time.monotonic()
    with (OUT/'logs'/f'{name}.log').open('w',encoding='utf-8') as log:
        completed=subprocess.run(command,cwd=ROOT,env=current,stdout=log,stderr=subprocess.STDOUT,check=False)
    step.update({'exit_code':completed.returncode,'elapsed_seconds':round(time.monotonic()-start,2),'finished_at':stamp()})
    metadata['steps'].append(step)
    (OUT/'execution_record.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DONE',name,'exit',completed.returncode,'seconds',step['elapsed_seconds'],flush=True)
    if completed.returncode:
        print((OUT/'logs'/f'{name}.log').read_text(encoding='utf-8')[-3000:],flush=True)
        raise RuntimeError(f'Step failed: {name}')

run('00_verify_inputs',['scripts/verify_package.py'])
run('01_unit_tests',['-m','pytest','-q','-p','no:cacheprovider','--basetemp',str(OUT/'pytest_temp'),'tests/test_chromatic.py'])
run('02_historical_neutral',['scripts/run_chromatic_robustness.py'],{'M3_CHROMATIC_OUT':str(OUT/'historical_neutral')})
run('03_regenerated_neutral',['scripts/run_chromatic_robustness.py'],{
    'M3_CHROMATIC_OUT':str(OUT/'new_generated_neutral'),'M3_REGENERATE_NEUTRAL':'1'})
run('04_public_codec_controls',['scripts/run_benign_chromatic_controls.py',
    '--video-dir',str(ROOT/'data/processed/m3_pilot'),'--out',str(OUT/'public_codec_controls')])
run('05_periodic_light_controls',['scripts/run_periodic_light_control.py',
    '--video-dir',str(ROOT/'data/processed/m3_pilot'),'--out',str(OUT/'periodic_light_controls')])

import numpy as np
import pandas as pd

comparisons=[]
for label,reference,current,keys in [
    ('historical_neutral','reference_results/historical_neutral/robustness_summary.csv','historical_neutral/robustness_summary.csv',['condition','channel']),
    ('new_generated_neutral','reference_results/new_generated_neutral/robustness_summary.csv','new_generated_neutral/robustness_summary.csv',['condition','channel']),
    ('public_codec_controls','reference_results/public_controls/benign_chromatic_controls.csv','public_codec_controls/benign_controls.csv',['clip_id']),
    ('periodic_light_controls','reference_results/public_controls/periodic_light_controls.csv','periodic_light_controls/periodic_light_controls.csv',['clip_id']),
]:
    a=pd.read_csv(ROOT/reference).sort_values(keys).reset_index(drop=True)
    b=pd.read_csv(OUT/current).sort_values(keys).reset_index(drop=True)
    if not a[keys].equals(b[keys]):
        raise ValueError(f'Unexpected row keys: {label}')
    for column in a.columns.intersection(b.columns):
        if column in keys or not (pd.api.types.is_numeric_dtype(a[column]) and pd.api.types.is_numeric_dtype(b[column])):
            continue
        diff=float((a[column]-b[column]).abs().max())
        comparisons.append({'suite':label,'column':column,'max_abs_difference':diff,
            'within_atol_1e_10_rtol_1e_8':bool(np.allclose(a[column],b[column],atol=1e-10,rtol=1e-8,equal_nan=True))})
pd.DataFrame(comparisons).to_csv(OUT/'reference_comparison.csv',index=False)

summaries={}
for name in ['historical_neutral','new_generated_neutral']:
    frame=pd.read_csv(OUT/name/'robustness_summary.csv')
    red=frame[frame.channel.eq('red')].set_index('condition').loc[['original','h264_crf35','resize_256','fps_15']]
    summaries[name]=red[['attack','neutral','attack_to_neutral_ratio']].reset_index().to_dict('records')
codec=pd.read_csv(OUT/'public_codec_controls/benign_controls.csv')
light=pd.read_csv(OUT/'periodic_light_controls/periodic_light_controls.csv')
summaries['public_codec_controls']={'n':len(codec),'median_fraction':float(codec.target_band_energy_fraction.median()),
    'min_fraction':float(codec.target_band_energy_fraction.min()),'max_fraction':float(codec.target_band_energy_fraction.max())}
summaries['periodic_light_controls']={'n':len(light),'above_neutral':int((light.periodic_fraction>light.neutral_fraction).sum()),
    'median_periodic_fraction':float(light.periodic_fraction.median()),'median_neutral_fraction':float(light.neutral_fraction.median())}
metadata['finished_at']=stamp()
metadata['comparison_within_tolerance']=all(row['within_atol_1e_10_rtol_1e_8'] for row in comparisons)
metadata['summary']=summaries
(OUT/'execution_record.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'all_steps_completed':True,'comparison_within_tolerance':metadata['comparison_within_tolerance'],'summary':summaries},ensure_ascii=False,indent=2),flush=True)
